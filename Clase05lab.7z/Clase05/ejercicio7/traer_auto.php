<?php
$archivo = fopen("auto.json","r+");
while(!feof($archivo))
{
    $auto = fread($archivo,sizeof($archivo));
}

echo $auto;