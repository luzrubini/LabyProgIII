<?php
    require_once "./clases/Ufologo.php";

    class Listado {
        public static function CrearListadoJson() {
            $auxReturn = "";
            $auxArray = Ufologo::TraerTodos();

            foreach ($auxArray as $ufologo) {
                $auxReturn.= $ufologo->ToJson()."<br>";
            }

            return $auxReturn;
        }
    }

    echo Listado::CrearListadoJson();