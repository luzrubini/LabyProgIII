<?php

class Ufologo
{
    private $_pais;
    private $_legajo;
    private $_clave;
    

    public function __construct($pais, $legajo, $clave) {
        $this->_pais = $pais;
        $this->_legajo = $legajo;
        $this->_clave = $clave;
    }
    public function ToJson() {
        $auxJson = new stdClass();
        $auxJson->pais= $this->_pais;
        $auxJson->legajo = $this->_legajo;
        $auxJson->clave = $this->_clave;
        return json_encode($auxJson);
    }

    public function GuardarEnArchivo() {
        $auxReturn = new stdClass();
        $file = fopen('./archivos/ufologos.json', "a+");
        if($file != false) {
            if(fwrite($file, $this->ToJson()."\r\n")) {
                $auxReturn->Exito = true;
                $auxReturn->Mensaje = "Se ha guardado en el archivo desde el metodo.";
            }
            
            fclose($file);
        }
        return $auxReturn;
    }

    public static function TraerTodos()
    {
        {
            $auxReturn = array();
            if(file_exists("./archivos/ufologos.json")) 
            {
                $ar = fopen("./archivos/ufologos.json", "r");
                if($ar != false) 
                {
                    while(!feof($ar)) 
                    {
                        $auxlinea = trim(fgets($ar));
                        if($auxlinea != "") 
                        {
                            $auxJson = json_decode($auxlinea);
                            $auxUfologo = new Ufologo($auxJson->pais, $auxJson->legajo,$auxJson->clave);
                            array_push($auxReturn, $auxUfologo);
                        }
                    }
                    fclose($ar);
                }
            }
            return $auxReturn;
        }
    }

    public static function VerificarExistencia($ufologo)
    {
        
        $auxReturn = false;
        $arrayUfologo = Ufologo::TraerTodos();
        foreach ($arrayUfologo as $ufo) {
            if($ufo->_legajo == $ufologo->_legajo && $ufo->_clave == $ufologo->_clave) {
                $auxReturn = true;
                break;
            }
        }
        return $auxReturn;
        
    }
}
