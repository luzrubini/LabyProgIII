<?php
require_once "./clases/Ufologo.php";

$auxReturn = new stdClass();
$auxReturn->Exito = false;
$auxReturn->Mensaje = "No hay alta";

$pais = isset($_POST['pais']) ? $_POST['pais'] : NULL;
$legajo = isset($_POST['legajo']) ? $_POST['legajo'] : NULL;
$clave = isset($_POST['clave']) ? $_POST['clave'] : NULL;
$alta = ($pais != "" && $legajo != "" && $clave !="") ? true : false;

if($alta) {
    $ufologo = new Ufologo($pais,$legajo,$clave);
    $objJson=$ufologo->GuardarEnArchivo();
    $auxReturn->Exito = true;
    $auxReturn->Mensaje = "Se ha guardado en el archivo desde UfologoAlta";
}
echo json_encode($auxReturn);


