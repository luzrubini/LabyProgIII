<?php
require_once "./clases/Ufologo.php";
$pais = isset($_POST['pais']) ? $_POST['pais'] : NULL;
$legajo = isset($_POST['legajo']) ? $_POST['legajo'] : NULL;
$clave = isset($_POST['clave']) ? $_POST['clave'] : NULL;           
$auxUfologo = new Ufologo($pais, $legajo, $clave);

if(Ufologo::VerificarExistencia($auxUfologo))
{
    $auxLegajo = str_replace(".", "_", $auxJson->legajo);
    setcookie($auxLegajo, date("YmdGis") , time()+360);
    header("location:ListadoUfologo.php");
}
else
{
    $retorno = new stdClass();
    $retorno->Exito=false;
    $retorno->Mensaje="El ufologo no existe";
    echo json_encode($retorno);
}
