<?php
    function saludar($nombre){
        echo "Hola $nombre \n";
    }
    //saludar('Pepe');
?>