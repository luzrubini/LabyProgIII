<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Clase 02</title>
</head>
<body>
    <form action="escribir.php" method="post" >
        Nombre: <input type="text" name="nombre" id="nombre"><br>
        Apellido: <input type="text" name="apellido" id="apellido"><br>
        <input type="submit" value="Enviar"><br>
        <input type="reset" value="Limpiar">
    </form>
</body>
</html>