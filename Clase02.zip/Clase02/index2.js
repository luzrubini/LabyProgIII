"use strict";
function Mostrar() {
    var nombre = document.getElementById("nombre").value;
    var edad = parseInt(document.getElementById("edad").value);
    alert("Nombre: " + nombre + "\nEdad: " + edad);
    console.log("Nombre: " + nombre + "\nEdad: " + edad);
}
//# sourceMappingURL=index2.js.map