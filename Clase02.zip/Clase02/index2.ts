    
function Mostrar():void {

    let nombre : string = (<HTMLInputElement> document.getElementById("nombre")).value;
    let edad : number = parseInt((<HTMLInputElement> document.getElementById("edad")).value);
    

    alert("Nombre: "+nombre+"\nEdad: "+edad);
    console.log("Nombre: "+nombre+"\nEdad: "+edad);
}