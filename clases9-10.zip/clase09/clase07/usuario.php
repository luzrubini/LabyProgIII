<?php

require_once "./AccesoDatos.php";

class Usuario {
    public function Verificar($request, $response, $next) {
        
        if ($request->isGet()) {
            $response->getBody()->write("Vengo por GET\n");
            $response = $next($request, $response);
        }
        else {
            $response->getBody()->write("Vengo de POST\n");
            $array= $request->getParsedBody();
            $usuarioObj = json_decode($array["usuario"]);
            if(!(Usuario::ExisteUsuario($usuarioObj))) {
            $response->getBody()->write("Usuario ".$usuarioObj->nombre." no valido");
            }
            else {
            $response->getBody()->write("Bienvenido, ".$usuarioObj->nombre."\n");
            $response =  $next($request, $response);
            }
        }
        return $response;
    }
    public static function ExisteUsuario($user) {
        $auxreturn = false;
        $file = fopen("./Usuarios.txt","r");
        if($file != false) {
            while(!feof($file)) {
                $auxLinea = trim(fgets($file));
                $auxArr = explode("-", $auxLinea);
                if($auxArr[0] == $user->nombre) {
                    if($auxArr[1] == $user->clave) {
                        $auxreturn = true;
                    }
                }
            }
        }
        fclose($file);
        return $auxreturn;
    }
} 