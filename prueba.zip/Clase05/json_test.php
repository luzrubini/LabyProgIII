<?php

	var_dump($_POST);
	$prod = JSON_decode($_POST["producto"]);
	var_dump($prod);
	$prod->precio=945;
	$prod->nombre="BIC";
	echo $nuevoProd = JSON_encode($prod);
