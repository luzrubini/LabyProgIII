"use strict";
/// <reference path="./ajax.ts"/>
var Ejercicio07;
(function (Ejercicio07) {
    function ObtenerJson() {
        var xhttps = new Ajax();
        var backend = "backend/traerAuto.php";
        var comando = "comando=traer";
        xhttps.Post(backend, Mostrar, comando, Fail);
    }
    Ejercicio07.ObtenerJson = ObtenerJson;
    function Mostrar(resultado) {
        var jsonObj = JSON.parse(resultado);
        //console.log(jsonObj);
        alert(jsonObj.Id + " - " + jsonObj.Marca + " - " + jsonObj.Precio + " - " + jsonObj.Color + " - " + jsonObj.Modelo);
        console.log(jsonObj.Id + " - " + jsonObj.Marca + " - " + jsonObj.Precio + " - " + jsonObj.Color + " - " + jsonObj.Modelo);
        ArmarInputs(jsonObj);
    }
    function Fail(resultado) {
        console.log("Error: " + resultado);
    }
    function ArmarInputs(jsonObj) {
        var auxReturn = "<table>";
        auxReturn += '<tr><td><input type="text" value="' + jsonObj.Id + '"</td></tr>';
        auxReturn += '<tr><td><input type="text" value="' + jsonObj.Marca + '"</td></tr>';
        auxReturn += '<tr><td><input type="text" value="' + jsonObj.Precio + '"</td></tr>';
        auxReturn += '<tr><td><input type="text" value="' + jsonObj.Color + '"</td></tr>';
        auxReturn += '<tr><td><input type="text" value="' + jsonObj.Modelo + '"</td></tr>';
        auxReturn += "</table>";
        document.getElementById("auxDiv").innerHTML = auxReturn;
    }
})(Ejercicio07 || (Ejercicio07 = {}));
//# sourceMappingURL=javascript.js.map