<?php

$queHago = isset($_POST['queHago']);

$host = "localhost";
$user = "root";
$pass = "";
$base = "mercado";

$con = @mysqli_connect($host, $user, $pass,$base);

if(!$con)
{
    echo "<pre>Error: No se pudo conectar a MySQL." . PHP_EOL;
    echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
    echo "error: " . mysqli_connect_error() . PHP_EOL . "</pre>";
    return;
}
switch ($queHago) {
    case 'TraerTodos_usuario':

        $sql = "SELECT `id`, `nombre`, `apellido`, `clave`, `perfil`, `estado` FROM `usuarios`";
        $rs = $con->query($sql);

        while ($row = $rs->fetch_object()){ //fetch_all / fetch_assoc / fetch_array([MYSQLI_NUM | MYSQLI_ASSOC | MYSQLI_BOTH])
            $user_arr[] = $row;
        }        
    
        echo "<pre>";
    
        var_dump($user_arr); 
        
        echo "</pre>";
        break;
        
    case 'TraerPorId_usuario':

        $sql = "SELECT  `nombre`, `apellido`, `clave`, `perfil`, `estado` FROM `usuarios` WHERE `id`= 3";
        $rs = $con->query($sql);

        while ($row = $rs->fetch_object()){ //fetch_all / fetch_assoc / fetch_array([MYSQLI_NUM | MYSQLI_ASSOC | MYSQLI_BOTH])
            $user_arr[] = $row;
        }        
    
        echo "<pre>";
    
        var_dump($user_arr); 
        
        echo "</pre>";
        break;
    case 'TraerPorEstado_usuario':

        echo "SELECT id, nombre, apellido, clave, perfil, estado FROM usuarios WHERE estado = 1";
        break;

    default:
        echo "default";
        break;
}
mysqli_close($con);