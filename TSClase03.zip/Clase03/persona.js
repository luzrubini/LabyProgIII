"use strict";
var Ejercicio;
(function (Ejercicio) {
    var Persona = /** @class */ (function () {
        function Persona(a, dni, n, s) {
            this._apellido = a;
            this._nombre = n;
            this._dni = dni;
            this._sexo = s;
        }
        Persona.prototype.GetApellido = function () {
            return this._apellido;
        };
        Persona.prototype.GetNombre = function () {
            return this._nombre;
        };
        Persona.prototype.GetDNI = function () {
            return this._dni;
        };
        Persona.prototype.GetSexo = function () {
            return this._sexo;
        };
        Persona.prototype.ToString = function () {
            return this._apellido + " - " + this._nombre + " - " + this._dni + " - " + this._sexo;
        };
        return Persona;
    }());
    Ejercicio.Persona = Persona;
})(Ejercicio || (Ejercicio = {}));
//# sourceMappingURL=persona.js.map