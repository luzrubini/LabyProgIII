/// <reference path="./empleado.ts" />
namespace Ejercicio
{

}