"use strict";
/// <reference path="./empleado.ts" />
//# sourceMappingURL=main.js.map