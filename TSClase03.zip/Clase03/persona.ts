namespace Ejercicio
{
    export abstract class Persona
    {
        private _apellido : string;
        private _dni : Number;
        private _nombre: string;
        private _sexo : CharacterData;

        public constructor(a:string, dni:number,n:string,s:CharacterData)
        {
            this._apellido=a;
            this._nombre=n;
            this._dni=dni;
            this._sexo=s;
        }

        public GetApellido():string
        {
            return this._apellido;
        }
        public GetNombre():string
        {
            return this._nombre;
        }
        public GetDNI():Number
        {
            return this._dni;
        }
        public GetSexo():CharacterData
        {
            return this._sexo;
        }

        public abstract Hablar(idioma:string):string;

        public ToString()
        {
            return this._apellido + " - " + this._nombre + " - " + this._dni + " - " + this._sexo;
        }

    }
}