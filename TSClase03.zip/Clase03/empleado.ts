/// <reference path="./persona.ts" />

namespace Ejercicio
{
    export class Empleado extends Persona
    {
        protected _legajo : number;
        protected _sueldo : number;

        public constructor(a:string, dni:number,n:string,s:CharacterData,l:number,sueldo:number)
        {
            super(a,dni,n,s);
            this._legajo=l;
            this._sueldo=sueldo;
        }
        public GetLegajo():number
        {
            return this._legajo;
        }
        public GetSueldo():number
        {
            return this._sueldo;
        }

        public Hablar(idioma:string):string
        {
            return "El empleado habla "+idioma;
        }
        public ToString()
        {
            return super.ToString()+ "- " + this._legajo + " - " + this._sueldo;
        }
    }
}