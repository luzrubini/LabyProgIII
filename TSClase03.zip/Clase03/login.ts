/// <reference path="./empleado.ts" />

if(localStorage.getItem("empleados") == null)
{
    localStorage.setItem("empleados","Juan-123,Rosa-456,Carlos-666");  
}

function Loguear(){
    let nombre: string = (<HTMLInputElement> document.getElementById("nombre")).value;
    let legajo: string = (<HTMLInputElement> document.getElementById("legajo")).value;

    var emp : string | null = localStorage.getItem("empleados");
    if(emp != null)
    {
        var array_emp = emp.split(",");
        for(var index = 0;index<=(array_emp.length)+1;index++)
        {
            var array_emp_2 = array_emp[index].split("-");
            if(array_emp_2[0] == nombre || array_emp_2[1] == legajo)
            {
                console.log("Usuario existente");
                window.location.href="principal.html"
                break;
            }
        }
        
        
    }
    
    

}