let num: number = 3;
let texto: string = "cadena de texto";

funcion(num, texto);
funcion(num);
