/**1. Realizar una aplicación que muestre los siguientes mensajes utilizando console.log() :
HOLA MUNDO!!!
Puedo mostrar comillas ‘simples’
Y comillas “dobles”
Nota : El mensaje se mostrará en una sola instrucción. Utilice caracteres de escape. Emplee
plantillas de string (tilde invertido). */

let mensaje: string = "HOLA MUNDO!!!";
console.log(mensaje);
console.log(`Puedo mostrar comillas ‘simples’`);
console.log('Y comillas “dobles”');
