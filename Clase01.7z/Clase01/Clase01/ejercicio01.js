"use strict";
/**1. Realizar una aplicación que muestre los siguientes mensajes utilizando console.log() :
HOLA MUNDO!!!
Puedo mostrar comillas ‘simples’
Y comillas “dobles”
Nota : El mensaje se mostrará en una sola instrucción. Utilice caracteres de escape. Emplee
plantillas de string (tilde invertido). */
var mensaje = "HOLA MUNDO!!!";
console.log(mensaje);
console.log("Puedo mostrar comillas \u2018simples\u2019");
console.log('Y comillas “dobles”');
//# sourceMappingURL=ejercicio01.js.map