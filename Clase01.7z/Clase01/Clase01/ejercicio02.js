"use strict";
/**2. Cree una aplicación que muestre, a través de un Array , los nombres de los meses de un
año y el número al que ese mes corresponde. Utilizar una estructura repetitiva para
escribir en la consola ( console.log() ). */
var meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
for (var index = 0; index < meses.length; index++) {
    console.log("Mes => " + meses[index] + " => " + (index + 1));
}
//# sourceMappingURL=ejercicio02.js.map