var nombre: string = "Gabriela";
var apellido: string = "Aragon";
console.log(nombre + " " + apellido);
