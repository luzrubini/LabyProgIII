"use strict";
var nombre = "Gabriela";
var apellido = "Aragon";
console.log(nombre + " " + apellido);
//# sourceMappingURL=inicio.js.map