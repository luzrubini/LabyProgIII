/**4. Realizar una función que reciba un número y que muestre (por consola) un mensaje
como el siguiente:
El número 5 es impar , siendo 5 el número recibido como parámetro. */

function parOImpar(numero: number) {
  if (numero % 2 == 1) {
    console.log("El numero " + numero + " es impar");
  }
}
