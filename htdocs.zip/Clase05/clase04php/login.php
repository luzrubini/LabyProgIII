<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
</head>
<body>
    <table align = "center">
        <td>Correo<input type="text" name="correo" id="correo"></td>
        <td>Clave<input type="text" name="clave" id="clave"></td>
        <td><input type="button" value="Aceptar"></td>
        <td><input type="button" value="Aceptar"></td>
        
    </table>
</body>
</html>