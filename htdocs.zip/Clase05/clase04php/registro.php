<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    Nombre <input type="text" name="nombre" id="nombre">
    Apellido <input type="text" name="apellido" id="apellido">
    Correo <input type="text" name="correo" id="correo">
    Clave <input type="text" name="clave" id="clave">
    Perfil <input type="text" name="perfil" id="perfil">
    <input type="button" value="Aceptar">
    <input type="button" value="Cancelar">
</body>
</html>