<?php

$queHago = isset($_POST['queHago']) ? $_POST['queHago'] : NULL;

$host = "localhost";
$user = "root";
$pass = "";
$base = "mercado";

$con = @mysqli_connect($host, $user, $pass, $base);

if(!$con)
{
    echo "<pre>Error: No se pudo conectar a MySQL." . PHP_EOL;
    echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
    echo "error: " . mysqli_connect_error() . PHP_EOL . "</pre>";
    return;
}

switch($queHago)
{
    case"TraerTodos_usuarios":

            $sql = "SELECT `id`, `nombre`, `apellido`, `clave`, `perfil`, `estado` FROM `usuarios`";
            $rs = $con->query($sql);
            
            while ($row = $rs->fetch_object()){ //fetch_all / fetch_assoc / fetch_array([MYSQLI_NUM | MYSQLI_ASSOC | MYSQLI_BOTH])
                $user_arr[] = $row;
            }        
          
            echo "<pre>";
            
            var_dump($user_arr); 
                
            echo "</pre>";

            echo "<pre>Cantidad de filas: " . mysqli_num_rows($rs) . "<br>mysqli_num_rows(rs)</pre>";

        break;

    case"TraerPorId_usuarios":

            $sql = "SELECT `nombre`, `apellido`, `clave`, `perfil`, `estado` FROM `usuarios` WHERE `id`=2";
            $rs = $con->query($sql);
        
            while ($row = $rs->fetch_object()){ //fetch_all / fetch_assoc / fetch_array([MYSQLI_NUM | MYSQLI_ASSOC | MYSQLI_BOTH])
                $user_arr[] = $row;
            }        
          
            echo "<pre>";

            var_dump($user_arr); 
                
            echo "</pre>"; 
            
        break; 
    
    case"TraerPorEstado_usuarios":

        $sql = "SELECT `id`, `nombre`, `apellido`, `clave`, `perfil` FROM `usuarios` WHERE `estado`=1";
        $rs = $con->query($sql);

        while ($row = $rs->fetch_object()){ //fetch_all / fetch_assoc / fetch_array([MYSQLI_NUM | MYSQLI_ASSOC | MYSQLI_BOTH])
            $user_arr[] = $row;
        }        
  
        echo "<pre>";
    
        var_dump($user_arr); 
        
        echo "</pre>"; 
    
    case"Agregar_usuarios":
        
        $sql = "INSERT INTO `usuarios`(`nombre`, `apellido`, `clave`, `perfil`, `estado`) VALUES ('Augus', 'Alvi', '1235', 2, 1)";

        $rs = $con->query($sql);
        echo "<pre>Filas afectadas: " . mysqli_affected_rows($con) . "<br>mysqli_affected_rows(con)</pre>";  

        break;
break;
    default:
    echo":(";
}
mysqli_close($con);

?>