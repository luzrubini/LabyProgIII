#estructura while
print("Simulador de niño de tres años")

print("Intenta detener esta locura")

respuesta = ""

while respuesta != "porque si":
	respuesta = input("¿Y por qué? ")

print("Ah, ok, gracias...")

input("Presione ENTER para continuar")