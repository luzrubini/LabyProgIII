
print("Esto es Seguridad Colador S.A")

password = input("Ingresar password: ")

if password == "secreto":
	print("Acceso permitido")
elif password == "secretito":
	print("Acceso permitidito")
else:
	print("Acceso denegado")

input("Presione ENTER para continuar")