nombre = input('Ingrese su nombre: ')

print('Hola', nombre)