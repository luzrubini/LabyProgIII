+ para sumar
- para restar
* para multiplicar
/ para dividir
// para dividir sin tener en cuenta los enteros
NO existe el ++ para incrementar en 1
NO existe el -- para decrementar en 1
.lower()
.upper()
.title()
.replace()