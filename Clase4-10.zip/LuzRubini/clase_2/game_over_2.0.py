# Uso de ',' en print, sirve para enviarle más de un string a la función 'print', la cual separa los strings con espacios
print('Programa', 'game over')

# Uso de print multi-línea
print("""
GGGGG  AAA  MM MM EEEEE
G     A   A M M M E
G  GG AAAAA M   M EEE
G   G A   A M   M E
GGGGG A   A M   M EEEEE

 OOO  V   V EEEEE RRRR
O   O V   V E     R   R
O   O V   V EEE   RRRR
O   O  V V  E     R  R
 OOO    V   EEEEE R   R

PPPP  EEEEE RRRR  DDD   EEEEE DDD    OOO  RRRR  !! !!
P   P E     R   R D  D  E     D  D  O   O R   R !! !!
PPPP  EEE   RRRR  D   D EEE   D   D O   O RRRR  !! !!
P     E     R  R  D  D  E     D  D  O   O R  R    
P     EEEEE R   R DDD   EEEEE DDD    OOO  R   R !! !!
""")

input('Presione ENTER para salir')