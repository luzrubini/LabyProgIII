#Ejemplos de For (1) range de 0-9
print("Contando los primeros 10 numeros")

for i in range(10):
	print(i)

#Ejemplo de For (2) el range va de 1 a 10
print("Contando del 1 al 10")

for i in range(1,11):
	print(i)

#Ejemplo de For (3) de 5 en 5
print("Contando de a 5")

for i in range(0,51,5):
	print(i)

#Ejemplo de For (4) para atras
print("Contando para atras")

for i in range(10,0,-1):
	print(i)