#Una tumpla de palabras, elijo una palabra de esa tupla,
#random.choice() elijo que palabra le doy al usuario, se resguarda la palabra.
#Se "bate la palabra" con random.shuffle()
import random

palabras = (
	"celular", "mouse", "pendrive", "teclado", "botella")

posicion = random.randrange(5)
palabra=(palabras[posicion])
palabra_lista = list(palabra)
random.shuffle(palabra_lista)
print("Palabra: ",palabra_lista)
palabra_ingresada = input('Ingrese la palabra ordenada: ')
print(palabra_ingresada)


input("Presione ENTER para continuar")
