
palabra = input("Ingrese una palabra: ")

print("Estas son las letras de la palabra: ")

for letra in palabra:
	print(letra)