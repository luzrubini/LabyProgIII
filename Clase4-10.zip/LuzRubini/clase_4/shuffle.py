import random

palabra = "Python3"

palabra_lista = list(palabra)

random.shuffle(palabra_lista)

print(palabra_lista)