import os
import sys

if sys.platform == 'linux':
	os.system('clear')

print('Ezequiel Mahafud\n')

print('"Tu vieja"')

print('- Pablo Neruda\n')

input('Presione ENTER para continuar')