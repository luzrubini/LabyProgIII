# Primer programa

print('Game Over\n')

input('Presionar ENTER para salir')