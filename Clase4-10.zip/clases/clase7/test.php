<?php

$msj = isset($_POST['mensaje']) ? $_POST['mensaje'] : null;
    $obj = new StdClass();
    $obj->mensaje = $msj;
    $obj->fecha = date("d:m:y");

    echo json_encode($obj);


$op = isset($_POST["op"]) ? $_POST["op"] : null;
switch ($op) {
    case "subirFoto":
        $objRetorno = new stdClass();
        $objRetorno->Ok = false;
        $destino = "./fotos/" . date("Ymd_His") . ".jpg";
        
        if(move_uploaded_file($_FILES["foto"]["tmp_name"], $destino) ){
            $objRetorno->Ok = true;
            $objRetorno->Path = $destino;
        }            
        echo json_encode($objRetorno);
        break;
    default:
            echo ":(";
            break;
    }