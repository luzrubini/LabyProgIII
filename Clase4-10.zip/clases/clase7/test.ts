/// <reference path="node_modules/@types/jquery/index.d.ts" />

function SubirFoto() : void {
    let auxInput : any = RecuperarFoto("foto");
    let form : FormData = new FormData();
    form.append("op","subirFoto"); 
    form.append("foto", auxInput[0].files[0]);

    let pagina = "BACKEND/nexo.php";
    $.ajax({
        type: 'POST',
        url: pagina,
        dataType: "json",
        cache: false,
        contentType: false,
        processData: false,
        data: form,
        async: true
    })
    .done(MostrarFoto)
    .fail(ErrorFunc);
}
function ErrorFunc(jsonAux : any) {
    console.log("Error: "+jsonAux);
}
function MostrarFoto(jsonAux: any) {
    //console.log(resultado);
    //let jsonAux : any = JSON.parse(resultado);

    if(jsonAux.Ok) {
        console.log("El JSON devolvió TRUE en Ok");        
        (<HTMLImageElement> document.getElementById("imgFoto")).src = "BACKEND/"+jsonAux.Path;
    }
    else {
        console.log("El JSON no devolvió TRUE en Ok");
    }
}
function RecuperarFoto(inputID : string) : any {
    let auxParam = "#"+inputID;
    return $(auxParam);
}