<?php
require_once __DIR__ . '/vendor/autoload.php';

header('content-type:application/pdf');

$mpdf = new \Mpdf\Mpdf(['orientation' => 'P', 
                        'pagenumPrefix' => 'Página nro. ',
                        'pagenumSuffix' => ' - ',
                        'nbpgPrefix' => ' de ',
                        'nbpgSuffix' => ' páginas']);//P-> vertical; L-> horizontal



$mpdf->SetHeader('{DATE j-m-Y}||{PAGENO}{nbpg}');
//alineado izquierda | centro | alineado derecha
$mpdf->setFooter('{DATE Y}|Programacón III|{PAGENO}');


$usuario = 'root';
$clave = '';

$db = new PDO('mysql:host=localhost;dbname=mercado;charset=utf8', $usuario, $clave);

$sql2 = $db->query('SELECT * FROM productos');

$catidadFilas = $sql2->rowCount();

$resultado = $sql2->fetchall();
if ($catidadFilas > 0) {
    $grilla = "<table border='1' align = 'center'>
                <tr>    
                <td>ID</td>
                <td>CODIGO DE BARRAS</td>
                <td>Nombre</td>
                <td>Foto</td>
                </tr>";

    foreach ($resultado as $fila) {
        $grilla .="<tr> <td>" . $fila['id'] . "</td>";
        $grilla .= "<td>" . $fila['codigo_barra'] . "</td>";
        $grilla .= "<td>" . $fila['nombre'] . "</td>";
        $grilla .= "<td><img src='archivos/".$fila['path_foto']."' width='100px' height='100px'/></td>" . "</tr>";
    }
    $grilla .= "</table>";
} else {
    $grilla .= "<tr>
            <td align='center' colspan='5'>NO EXISTEN PRODUCTOS</td>
        </tr>";
}

$mpdf->WriteHTML("<h3>Listado de Productos</h3>");
$mpdf->WriteHTML("<br>");

$mpdf->WriteHTML($grilla);

$mpdf->Output('Lista_Usuarios.pdf', 'I');