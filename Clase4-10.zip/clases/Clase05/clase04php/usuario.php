<?php
class Usuario
{
    private $_id;
    private $_nombre;
    private $_apellido;
    private $_correo;
    private $_clave;
    private $_perfil;
    private $_estado;
    private $_foto;

    /*public __construct($id,$nombre,$apellido,$correo,$clave,$perfil,$estado,$foto)
    {
        $this->_nombre = $nombre;
        $this->_apellido = $apellido;
        $this->_correo = $correo;
        $this->_clave = $clave;

    }*/


}
   