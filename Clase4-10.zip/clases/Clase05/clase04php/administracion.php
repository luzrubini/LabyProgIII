<?php
$queHago = isset($_POST['queHago']) ? $_POST['queHago'] : NULL;

$usuario = "root";
$clave = "";

switch ($queHago) {
    case "TraerTodos_Usuarios":
        $obj = new stdClass();
        $obj->Exito = TRUE;
        $obj->Mensaje = "";
        $obj->Html = "";

        try {
            //CREO INSTANCIA DE PDO, INDICANDO ORIGEN DE DATOS, USUARIO Y CONTRASEÑA
            $usuario = 'root';
            $clave = '';

            $db = new PDO('mysql:host=localhost;dbname=mercado;charset=utf8', $usuario, $clave);
            $obj->Mensaje = "FETCHALL";

            $sql = $db->query('SELECT * FROM usuarios');

            $catidadFilas = $sql->rowCount();

            $obj->Html = "Cantidad de filas: " . $catidadFilas . "---";

            $resultado = $sql->fetchall();
            if ($catidadFilas > 0) {
                $obj->Html = "<table border='1'>
        <tr>    
            <td>ID</td>
            <td>Nombre</td>
            <td>Apellido</td>
            <td>Perfil</td>
            <td>Estado</td>
        </tr><tr>";

                foreach ($resultado as $fila) {
                    $obj->Html .= "<td>" . $fila['id'] . "</td>";
                    $obj->Html .= "<td>" . $fila['nombre'] . "</td>";
                    $obj->Html .= "<td>" . $fila['apellido'] . "</td>";
                    $obj->Html .= "<td>" . $fila['perfil'] . "</td>";
                    $obj->Html .= "<td>" . $fila['estado'] . "</td>" . "</tr>";
                }
                $obj->Html .= "</table>";
            } else {
                $obj->Html .= "<tr>
                        <td align='center' colspan='5'>NO EXISTEN USUARIOS</td>
                    </tr>";
            }
        } catch (PDOException $e) {

            $obj->Exito = FALSE;
            $obj->Mensaje = "Error!!!\n" . $e->getMessage();
        }
        echo $obj->Html;
        break;

    case "TraerTodos_PorID":
        $id = isset($_POST['id']) ? $_POST['id'] : NULL;

        try {
            //CREO INSTANCIA DE PDO, INDICANDO ORIGEN DE DATOS, USUARIO Y CONTRASEÑA
            $usuario = 'root';
            $clave = '';

            $pdo = new PDO('mysql:host=localhost;dbname=mercado;charset=utf8', $usuario, $clave);

            //CON PARAMETRO NOMBRADO
            $sentencia = $pdo->prepare('SELECT nombre AS nomb, apellido AS apell, perfil AS perf, estado AS estad FROM usuarios WHERE id = :id');

            $sentencia->execute(array("id" => $id));

            $tabla =    "<table border='1'>
                <tr>
                    <td>ID</td>
                    <td>Nombre</td>
                    <td>Apellido</td>
                    <td>Perfil</td>
                    <td>Estado</td>
                </tr><tr><td>";
            while ($fila = $sentencia->fetch()) {
                $tabla .= $id . "</td><td>{$fila['nomb']}</td><td>{$fila['apell']}</td><td>{$fila['perf']}</td><td>{$fila['estad']}</td></tr>";
            }
            $tabla .= "</table>";

            echo $tabla;
        } catch (PDOException $e) {
            echo "Error!!!\n" . $e->getMessage();
        }
        break;

    case "TraerTodos_PorEstado":
        $estado = isset($_POST['estado']) ? $_POST['estado'] : NULL;

        try {
            //CREO INSTANCIA DE PDO, INDICANDO ORIGEN DE DATOS, USUARIO Y CONTRASEÑA
            $usuario = 'root';
            $clave = '';

            $pdo = new PDO('mysql:host=localhost;dbname=mercado;charset=utf8', $usuario, $clave);

            //CON PARAMETRO NOMBRADO
            $sentencia = $pdo->prepare('SELECT id AS id,nombre AS nomb, apellido AS apell, perfil AS perf FROM usuarios WHERE estado = :estado');

            $sentencia->execute(array("estado" => $estado));

            $tabla =    "<table border='1'>
                <tr>
                    <td>ID</td>
                    <td>Nombre</td>
                    <td>Apellido</td>
                    <td>Perfil</td>
                    <td>Estado</td>
                </tr>";
            $catidadFilas = $sentencia->rowCount();
            if ($catidadFilas > 0) {


                while ($fila = $sentencia->fetch()) {
                    $tabla .= "<tr><td>{$fila['id']}</td><td>{$fila['nomb']}</td><td>{$fila['apell']}</td><td>{$fila['perf']}</td><td>" . $estado . "</td></tr>";
                }
            } else {
                $tabla .= "<tr><td>align='center' colspan='5'>NO EXISTEN USUARIOS</td></tr>";
            }

            $tabla .= "</table>";

            echo $tabla;
        } catch (PDOException $e) {
            echo "Error!!!\n" . $e->getMessage();
        }
        break;

    case "CargarNuevoUsuario":
        /*$cargado = $_POST["cargar"];
        $con = @mysqli_connect($host, $user, $pass, $base2);
        $sql = $cargado;
        $rs = $con->query($sql);
        echo "Codigo generado: " + $cargado;
        mysqli_close($con);*/
        break;

    case "EliminarUsuario":
        /*$idEliminada = $_POST["idEliminar"];
        $con = @mysqli_connect($host, $user, $pass, $base2);
        $sql = "DELETE FROM `usuarios` WHERE `id` =" . $idEliminada;
        $rs = $con->query($sql);
        mysqli_close($con);*/
        break;
    case "ModificarUsuario":
        /*$usuarioModificado = $_POST["cargarModificacion"];
        $con = @mysqli_connect($host, $user, $pass, $base2);
        $sql = $usuarioModificado;
        $rs = $con->query($sql);
        echo "Codigo generado: " + $usuarioModificado;
        mysqli_close($con);*/
        break;
    default:
        echo ":(";
}
