<?php
$obj = new stdClass();
$obj->Exito = TRUE;
$obj->Mensaje = "";
$obj->Html = "";
try {
    //CREO INSTANCIA DE PDO, INDICANDO ORIGEN DE DATOS, USUARIO Y CONTRASEÑA
    $usuario = 'root';
    $clave = '';
    $objetoPDO = new PDO('mysql:host=localhost;dbname=cdcol;charset=utf8', $usuario, $clave);
    $obj->Html = "objetoPDO = new PDO('mysql:host=localhost;dbname=cdcol;charset=utf8', 'root', '')";
    $obj->Mensaje = "Conexión establecida!!!";

    //$sql = $objetoPDO->query('SELECT titel AS titulo, interpret AS interprete, jahr AS anio FROM cds'); 
    $sql = $objetoPDO->query('SELECT * FROM cds'); //consulya con el nombre de la tabla
    $resultado = $sql->fetchall();
    foreach ($resultado as $fila) {
        var_dump($fila[0],$fila[1],$fila[2]);
        //$obj->Html .= "- Título: " . $fila['titulo'];
        //$obj->Html .= "- Año: " . $fila['anio'];
        //$obj->Html .= "- Cantante: " . $fila['interprete'] . "-";
    }
} catch (PDOException $e) {
    $obj->Exito = FALSE;
    $obj->Mensaje = "Error!!!\n" . $e->getMessage();
}
echo json_encode($obj);
